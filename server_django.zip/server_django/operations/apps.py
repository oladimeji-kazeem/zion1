from django.apps import AppConfig


class OperationsConfig(AppConfig):
    name = "operations"
