#!/usr/bin/env python
# -*- coding: utf-8 -*-

template_content = """{% extends 'base.html' %}
{% load humanize %}

{% block header_title %}Staff & Employees{% endblock %}

{% block header_actions %}
<div class="flex items-center gap-3">
    <a href="{% url 'hr-dashboard' %}" class="px-4 py-2 bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 rounded-xl text-sm font-bold border border-white/10 hover:bg-slate-200 transition-all">
        <i data-lucide="layout-dashboard" class="w-4 h-4 inline-block mr-1"></i> HR Stats
    </a>
    <a href="{% url 'employee-create' %}" class="px-4 py-2 bg-brand-navy dark:bg-brand-teal text-white rounded-xl text-sm font-bold shadow-lg shadow-brand-navy/20 dark:shadow-brand-teal/20 hover:scale-105 transition-all">
        <i data-lucide="user-plus" class="w-4 h-4 inline-block mr-1"></i> Add Employee
    </a>
</div>
{% endblock %}

{% block content %}
<div class="space-y-6">
    <div class="glass p-6 rounded-3xl border border-white/10">
        <form method="GET" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div class="relative lg:col-span-2">
                <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"></i>
                <input type="text" name="search" value="{{ current_filters.search }}" placeholder="Search by name, ID or email..." class="w-full pl-11 pr-4 py-3 bg-white/5 border border-white/10 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-navy/30 dark:text-white">
            </div>
            <select name="department" class="px-4 py-3 bg-white/5 border border-white/10 rounded-2xl text-sm focus:outline-none dark:text-white">
                <option value="">All Departments</option>
                {% for dept in departments %}
                <option value="{{ dept.id }}" {% if current_filters.department == dept.id|stringformat:"s" %}selected{% endif %}>{{ dept.name }}</option>
                {% endfor %}
            </select>
            <select name="status" class="px-4 py-3 bg-white/5 border border-white/10 rounded-2xl text-sm focus:outline-none dark:text-white">
                <option value="">All Status</option>
                {% for code, label in status_choices %}
                <option value="{{ code %}}" {% if current_filters.status == code %}selected{% endif %}>{{ label }}</option>
                {% endfor %}
            </select>
            <button type="submit" class="px-6 py-3 bg-slate-900 dark:bg-brand-teal/20 text-white rounded-2xl text-sm font-bold hover:bg-slate-800 transition-all">Apply Filters</button>
        </form>
    </div>
    <div class="glass rounded-3xl border border-white/10 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-slate-50/50 dark:bg-white/5 border-b border-white/10">
                        <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Employee</th>
                        <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">ID / Dept</th>
                        <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Role</th>
                        <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Hire Date</th>
                        <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest">Status</th>
                        <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-widest text-right">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-white/5">
                    {% for e in employees %}
                    <tr class="hover:bg-white/5 transition-all">
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-navy to-brand-navy/60 flex items-center justify-center text-white font-bold">
                                    {{ e.first_name|first }}{{ e.last_name|first }}
                                </div>
                                <div>
                                    <p class="text-sm font-bold text-slate-900 dark:text-white">{{ e.get_full_name }}</p>
                                    <p class="text-[10px] text-slate-500">{{ e.email }}</p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <p class="text-xs font-bold text-slate-700 dark:text-slate-300">{{ e.employee_id }}</p>
                            <p class="text-[10px] text-slate-500">{{ e.department.name|default:"Unassigned" }}</p>
                        </td>
                        <td class="px-6 py-4">
                            <span class="text-xs text-slate-600 dark:text-slate-400">{{ e.job_title }}</span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="text-xs text-slate-500">{{ e.hire_date|date:"M d, Y" }}</span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2.5 py-1 rounded-full text-[10px] font-bold {% if e.status == 'active' %}bg-green-100 text-green-600{% elif e.status == 'on_leave' %}bg-blue-100 text-blue-600{% else %}bg-slate-100 text-slate-500{% endif %} uppercase tracking-wider">
                                {{ e.get_status_display }}
                            </span>
                        </td>
                        <td class="px-6 py-4 text-right">
                            <a href="{% url 'employee-detail' e.pk %}" class="p-2 hover:bg-slate-100 dark:hover:bg-white/10 rounded-lg inline-block transition-colors">
                                <i data-lucide="chevron-right" class="w-4 h-4 text-slate-400"></i>
                            </a>
                        </td>
                    </tr>
                    {% empty %}
                    <tr>
                        <td colspan="6" class="px-6 py-12 text-center text-slate-500 italic text-sm">No employees found matching your criteria.</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
    </div>
</div>
{% endblock %}
"""

with open('templates/employees/employee_list.html', 'w', encoding='utf-8', newline='\n') as f:
    f.write(template_content)

print("Template written successfully!")
print(f"File size: {len(template_content)} bytes")
