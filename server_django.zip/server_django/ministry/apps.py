from django.apps import AppConfig


class MinistryConfig(AppConfig):
    name = "ministry"
