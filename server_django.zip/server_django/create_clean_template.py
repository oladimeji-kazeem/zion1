
import os

content = """{% extends 'base.html' %}
{% load humanize operations_extras %}

{% block content %}
<div class="space-y-6">
    <!-- Header -->
    <div class="flex justify-between items-center">
        <div>
            <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Financial Dashboard (V8 Generated)</h1>
            <p class="text-slate-500 dark:text-slate-400">Overview of Church Treasury</p>
        </div>
        <div class="flex gap-3">
            <a href="{% url 'financial-income-create' %}" class="flex items-center gap-2 bg-brand-navy hover:bg-brand-dark text-white px-4 py-2 rounded-lg transition-colors">
                <i data-lucide="plus"></i>
                <span>Record Income</span>
            </a>
            <a href="{% url 'financial-expense-create' %}" class="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors">
                <i data-lucide="minus"></i>
                <span>Record Expense</span>
            </a>
            <a href="{% url 'financial-reports' %}" class="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300 px-4 py-2 rounded-lg transition-colors">
                <i data-lucide="file-text"></i>
                <span>Reports</span>
            </a>
        </div>
    </div>

    <!-- KPIs -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- Income YTD -->
        <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700">
            <div class="flex justify-between items-start">
                <div>
                    <p class="text-xs font-medium uppercase tracking-wider text-slate-500 dark:text-slate-400">Total Income (YTD)</p>
                    <h3 class="text-2xl font-bold text-slate-900 dark:text-white mt-1">&pound;{{ kpi.income_ytd|int_abbrev }}</h3>
                </div>
                <div class="p-2 bg-green-50 dark:bg-green-900/20 text-green-600 rounded-lg">
                    <i data-lucide="trending-up" class="w-5 h-5"></i>
                </div>
            </div>
            <p class="text-sm text-slate-500 mt-4 flex items-center gap-1">
                <span class="text-green-600 font-medium">+&pound;{{ kpi.income_month|int_abbrev }}</span> in {{ "now"|date:"F" }}
            </p>
        </div>

        <!-- Expense YTD -->
        <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700">
            <div class="flex justify-between items-start">
                <div>
                    <p class="text-xs font-medium uppercase tracking-wider text-slate-500 dark:text-slate-400">Total Expenses (YTD)</p>
                    <h3 class="text-2xl font-bold text-slate-900 dark:text-white mt-1">&pound;{{ kpi.expense_ytd|int_abbrev }}</h3>
                </div>
                <div class="p-2 bg-red-50 dark:bg-red-900/20 text-red-600 rounded-lg">
                    <i data-lucide="trending-down" class="w-5 h-5"></i>
                </div>
            </div>
            <p class="text-sm text-slate-500 mt-4 flex items-center gap-1">
                <span class="text-red-600 font-medium">+&pound;{{ kpi.expense_month|int_abbrev }}</span> in {{ "now"|date:"F" }}
            </p>
        </div>

        <!-- Net Income -->
        <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700">
            <div class="flex justify-between items-start">
                <div>
                    <p class="text-xs font-medium uppercase tracking-wider text-slate-500 dark:text-slate-400">Net Position (YTD)</p>
                    <h3 class="text-2xl font-bold {% if kpi.net_income >= 0 %}text-green-600{% else %}text-red-600{% endif %} mt-1">&pound;{{ kpi.net_income|int_abbrev }}</h3>
                </div>
                <div class="p-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 rounded-lg">
                    <i data-lucide="activity" class="w-5 h-5"></i>
                </div>
            </div>
            <p class="text-sm text-slate-500 mt-4">Calculated as Income - Expenses</p>
        </div>

        <!-- Operational Efficiency -->
        <div class="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700">
            <div class="flex justify-between items-start">
                <div>
                    <p class="text-xs font-medium uppercase tracking-wider text-slate-500 dark:text-slate-400">Operational Efficiency</p>
                    <h3 class="text-2xl font-bold text-slate-900 dark:text-white mt-1">{% if kpi.income_ytd > 0 %}{{ kpi.operational_efficiency|floatformat:1 }}% Used{% else %}N/A{% endif %}</h3>
                </div>
                <div class="p-2 bg-purple-50 dark:bg-purple-900/20 text-purple-600 rounded-lg">
                    <i data-lucide="pie-chart" class="w-5 h-5"></i>
                </div>
            </div>
            <p class="text-sm text-slate-500 mt-4">% of Income spent on Expenses</p>
        </div>
    </div>

    <!-- Recent Transactions Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Income -->
        <div class="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col">
            <div class="p-6 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center">
                <h3 class="font-bold text-slate-800 dark:text-white">Recent Inflows</h3>
                <a href="{% url 'financial-income-list' %}" class="text-sm text-brand-navy hover:underline">View All</a>
            </div>
            <div class="p-0 flex-1">
                <table class="w-full text-left text-sm">
                    <thead class="bg-slate-50 dark:bg-slate-900/50 text-slate-500 dark:text-slate-400">
                        <tr>
                            <th class="px-6 py-3 font-medium">Date</th>
                            <th class="px-6 py-3 font-medium">Category</th>
                            <th class="px-6 py-3 font-medium text-right">Amount</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                        {% for item in recent_income %}
                        <tr class="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                            <td class="px-6 py-3 text-slate-600 dark:text-slate-300">{{ item.date|date:"M d" }}</td>
                            <td class="px-6 py-3">
                                <span class="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">{{ item.category }}</span>
                            </td>
                            <td class="px-6 py-3 text-right font-medium text-slate-900 dark:text-white">&pound;{{ item.amount|intcomma }}</td>
                        </tr>
                        {% empty %}
                        <tr>
                            <td colspan="3" class="px-6 py-8 text-center text-slate-500">No recent income recorded.</td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Recent Expenses -->
        <div class="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col">
            <div class="p-6 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center">
                <h3 class="font-bold text-slate-800 dark:text-white">Recent Outflows</h3>
                <a href="{% url 'financial-expense-list' %}" class="text-sm text-brand-navy hover:underline">View All</a>
            </div>
            <div class="p-0 flex-1">
                <table class="w-full text-left text-sm">
                    <thead class="bg-slate-50 dark:bg-slate-900/50 text-slate-500 dark:text-slate-400">
                        <tr>
                            <th class="px-6 py-3 font-medium">Date</th>
                            <th class="px-6 py-3 font-medium">Category</th>
                            <th class="px-6 py-3 font-medium text-right">Amount</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                        {% for item in recent_expenses %}
                        <tr class="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                            <td class="px-6 py-3 text-slate-600 dark:text-slate-300">{{ item.date|date:"M d" }}</td>
                            <td class="px-6 py-3">
                                <span class="px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400">{{ item.category }}</span>
                            </td>
                            <td class="px-6 py-3 text-right font-medium text-slate-900 dark:text-white">&pound;{{ item.amount|intcomma }}</td>
                        </tr>
                        {% empty %}
                        <tr>
                            <td colspan="3" class="px-6 py-8 text-center text-slate-500">No recent expenses recorded.</td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
{% endblock %}
"""

file_path = r'c:\Users\oladi\sources\rccghgz\server_django\templates\operations\financial_dashboard_v8.html'
with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print(f"Recursively created clean template at {file_path}")
